# Bundled MRI sample: MSD Task01 BrainTumour

Case: BRATS_457.nii.gz, from Medical Segmentation Decathlon Task01_BrainTumour,
release 2.0 (04/05/2018), derived from BraTS glioma data.

Credit: Medical Segmentation Decathlon organizers and original BraTS data contributors.
Dataset reference supplied in dataset.json: https://www.med.upenn.edu/sbia/brats2017.html
Dataset website: https://medicaldecathlon.com/
Source archive: https://msd-for-monai.s3.us-west-2.amazonaws.com/Task01_BrainTumour.tar
Registry: https://registry.opendata.aws/msd/ (checked 2026-10-18).

License: Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0).
License and terms: https://creativecommons.org/licenses/by-sa/4.0/
Legal code: https://creativecommons.org/licenses/by-sa/4.0/legalcode
This sample is not covered by the repository's MIT code license.

Citation: Simpson AL, Antonelli M, Bakas S, et al. A large annotated medical image
 dataset for the development and evaluation of segmentation algorithms (2019).
https://arxiv.org/abs/1902.09063

Changes: one image/mask pair and the dataset metadata were selected from the
source archive and repackaged as a ZIP with a generated download manifest and
this attribution notice. MRI, mask, and dataset.json contents are unchanged from
the locally supplied sample. No endorsement by the data creators is implied.

The labels describe edema, non-enhancing tumor, and enhancing tumor regions,
not tumor-type diagnoses. This single case is for learning and format checks;
it cannot establish generalization performance or support a patient-level split.
